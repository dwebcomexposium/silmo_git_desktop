/* Newsletter fix */

jQuery(function($){

$('#zone2 > div.block.block-small.quicklinks.acces-rapide > ul > li.ql-item.linkid238551 > a, body > div.global-wrapper > header > div > div.block.block-small.quicklinks.lien-fixed-social > ul > li.ql-item.linkid238970 > a, #zone2 > div.block.block-small.quicklinks.lien-suiveznous > ul > li.ql-item.linkid238970 > a, .linkid238551 a').attr("onclick","xt_med('C','','::Newsletter_subscription','N')");

});